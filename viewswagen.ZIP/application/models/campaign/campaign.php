<?php
class Campaign extends CI_Model 
{
    private $_entity_id = 'campaign_id';
    private $_data = array();
    function __construct() {
        parent::__construct();
    }
    
    public function setData($data) {
        $this->_data = $data;
        return $this;
    }
    
    public function getData($key=false) {
        if($key && isset($this->_data->$key)) {
            return $this->_data->$key;
        }
        return $this->_data;
    }

    public function getCampaignList() {
        
    }
    
    public function getCampaign($campaignId) {
        $this->db->from('ci_campaigns');
        $this->db->where($this->_entity_id, $campaignId);
        $this->db->where('owner_id', $this->session->userdata('id'));
        $this->db->join('ci_campaigns_media', 'ci_campaigns.campaign_id = ci_campaigns_media.campaign','left');
        $query = $this->db->get();
        if ($query->num_rows() > 0 ) {
            $row = $query->row_array();
            return $row;
        }
        return false;
    }
    
    public function setCampaign($campaignData) {
        $this->_data=$campaignData;
        return $this;
    }
    
    public function save() {
        $data = $this->_data;
        $filedata = FALSE;
        $mediaExists = false;
        if(!isset($data[$this->_entity_id])) {
            $data[$this->_entity_id] = '';
        }
        $filePost = $data['file_data'];
        unset($data['file_data']);
        if($filePost) {
            $filePost = json_decode($filePost);
            
            $filedata['real_path']      = $filePost->data->full_path;
            $filedata['absolute_url']   = HTTP_BASE_URL."uploads/".$this->session->userdata('id').'/'.$filePost->data->file_name;
            $filedata['owner']       = $this->session->userdata('id');
        }
        try {
            if(!$data[$this->_entity_id]) {
                $this->db->insert('ci_campaigns', $data);
                $result = $this->getCampaign($this->db->insert_id());
            } else {
                if($filedata) {
                    $this->_data['status'] = 1;
                    $mediaExists = true;
                }
                $this->db->update('ci_campaigns', 
                        $data,
                        array('owner_id' => $this->session->userdata('id'),$this->_entity_id => $this->_data[$this->_entity_id]));
                
            $result = $this->_data;
            }
            $filedata['campaign'] = $result[$this->_entity_id];
            if($filedata) {
                if($mediaExists) {
                    $this->db->update('ci_campaigns_media',$filedata,array('campaign_id'=>$filedata['campaign_id']));
                } else {
                    $filedata['media_id']= '';
                    $this->db->insert('ci_campaigns_media',$filedata);
                }
            }
    
        } catch (Exception $e) {
            $result = $e->getMessage();
        }
        return $result;
    }


    public function removeCampaign($campaignId) {
        
    }
    
    
}