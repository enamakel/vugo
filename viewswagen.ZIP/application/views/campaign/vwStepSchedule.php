<div class="panel panel-default ng-scope">
    <div class="panel-heading">
        <button ng-click="schedule.edit()" ng-show="schedule.status == 2" class="pull-right btn btn-default ng-hide">Edit</button>
        <h5 class="panel-title">
        <i class="fa fa-calendar">
        </i>&nbsp;Schedule</h5>
        <div ng-show="schedule.status & gt; 0" class="small text-muted ng-hide">Please choose schedule for your campaign</div>
    </div>
    <div ng-show="schedule.status & gt; 0" class="slide-animation ng-hide">
        <div ng-form="scheduleForm" class="panel-body ng-pristine ng-valid ng-valid-required">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <b>Campaign starts...</b>
                        <div ng-show="schedule.status == 1" class="ng-hide">
                            <div ng-click="schedule.dateStartOption = 0" style="cursor:pointer">
                                <i ng-class="{'fa-check-square-o':schedule.dateStartOption == 0,'fa-square-o':schedule.dateStartOption != 0}" class="fa fa-check-square-o"></i>&nbsp;as soon as possible (once approved)
                            </div>
                            <div ng-click="schedule.dateStartOption = 1" style="cursor:pointer">
                                <i ng-class="{'fa-check-square-o':schedule.dateStartOption == 1,'fa-square-o':schedule.dateStartOption != 1}" class="fa fa-square-o"></i>&nbsp;on specific date
                            </div>
                        </div>
                        <div ng-show="schedule.status == 2" class="ng-hide">
                            <div ng-show="schedule.dateStartOption == 0" class="">as soon as possible (once approved)</div>
                            <div ng-show="schedule.dateStartOption == 1" class="ng-binding ng-hide">on </div>
                        </div>
                    </div>
                    <div ng-show="schedule.dateStartOption == 1 & amp; & amp; schedule.status == 1" class="slide-animation ng-hide">
<!-- calendar from -->
                        <!--
                        <table class="well well-sm ng-isolate-scope ng-pristine ng-valid ng-valid-date ng-valid-date-disabled" show-weeks="true" min="schedule.pickerMin|date:'medium'" ng-model="schedule.dateStart" style="width:100%">
<thead>
<tr>
<th>
<button ng-click="move( - 1)" class="btn btn-default btn-sm pull-left" type="button">
    <i class="fa fa-chevron-left"></i>
</button>
</th>
<th colspan="6">
<button ng-click="toggleMode()" class="btn btn-default btn-sm btn-block" type="button">
<strong class="ng-binding">May 2015</strong>
</button>
</th>
<th>
<button ng-click="move(1)" class="btn btn-default btn-sm pull-right" type="button">
    <i class="fa fa-chevron-right"></i>
</button>
</th>
</tr>
<tr class="h6" ng-show="labels.length & gt; 0">
<th class="text-center" ng-show="showWeekNumbers">#</th>
ngRepeat: label in labels 
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Sun</th>
end ngRepeat: label in labels 
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Mon</th>
end ngRepeat: label in labels 
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Tue</th>
end ngRepeat: label in labels 
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Wed</th>
end ngRepeat: label in labels 
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Thu</th>
end ngRepeat: label in labels 
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Fri</th>
end ngRepeat: label in labels 
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Sat</th>
end ngRepeat: label in labels 
</tr>
</thead>
<tbody>
ngRepeat: row in rows 
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">17</em>
</td>
ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">26</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">27</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">28</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">29</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">30</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">01</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">02</span>
</button>
</td>
end ngRepeat: dt in row 
</tr>
end ngRepeat: row in rows 
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">18</em>
</td>
ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">03</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">04</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">05</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">06</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">07</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">08</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">09</span>
</button>
</td>
end ngRepeat: dt in row 
</tr>
end ngRepeat: row in rows 
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">19</em>
</td>
ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">10</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">11</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">12</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">13</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">14</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">15</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">16</span>
</button>
</td>
end ngRepeat: dt in row 
</tr>
end ngRepeat: row in rows 
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">20</em>
</td>
ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">17</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">18</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">19</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">20</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">21</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">22</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">23</span>
</button>
</td>
end ngRepeat: dt in row 
</tr>
end ngRepeat: row in rows 
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">21</em>
</td>
ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">24</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">25</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">26</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">27</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">28</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">29</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">30</span>
</button>
</td>
end ngRepeat: dt in row 
</tr>
end ngRepeat: row in rows 
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">22</em>
</td>
ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">31</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">01</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">02</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">03</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">04</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">05</span>
</button>
</td>
end ngRepeat: dt in row 
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">06</span>
</button>
</td>
end ngRepeat: dt in row 
</tr>
end ngRepeat: row in rows 
</tbody>
</table>
                        -->
<!-- end calendar from -->
                        <input type="hidden" ng-required="schedule.dateStartOption==1" ng-model="schedule.dateStart" name="dateStart" class="ng-pristine ng-valid ng-valid-required">
                    </div>
                </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <b>Campaign ends...</b>
                    <div ng-show="schedule.status == 1" class="ng-hide">
                        <div ng-click="schedule.dateEndOption = 0" style="cursor:pointer">
                            <i ng-class="{'fa-check-square-o':schedule.dateEndOption == 0,'fa-square-o':schedule.dateEndOption != 0}" class="fa fa-check-square-o">
                            </i>&nbsp;when balance exceeded
                        </div>
                        <div ng-click="schedule.dateEndOption = 1" style="cursor:pointer">
                            <i ng-class="{'fa-check-square-o':schedule.dateEndOption == 1,'fa-square-o':schedule.dateEndOption != 1}" class="fa fa-square-o">
                            </i>&nbsp;on specific date
                        </div>
                    </div>
                    <div ng-show="schedule.status == 2" class="ng-hide">
                        <div ng-show="schedule.dateEndOption == 0" class="">when balance exceeded</div>
                        <div ng-show="schedule.dateEndOption == 1" class="ng-binding ng-hide">on </div>
                    </div>
                </div>
                <div ng-show="schedule.dateEndOption == 1 & amp; & amp; schedule.status == 1" class="slide-animation ng-hide">
<!-- calendar to -->
                    <table class="well well-sm ng-isolate-scope ng-pristine ng-valid ng-valid-date ng-valid-date-disabled" show-weeks="true" min="(schedule.dateStart||schedule.pickerMin)|date:'medium'" ng-model="schedule.dateEnd" style="width:100%">
<thead>
<tr>
<th>
<button ng-click="move( - 1)" class="btn btn-default btn-sm pull-left" type="button">
<i class="fa fa-chevron-left">
</i>
</button>
</th>
<th colspan="6">
<button ng-click="toggleMode()" class="btn btn-default btn-sm btn-block" type="button">
<strong class="ng-binding">May 2015</strong>
</button>
</th>
<th>
<button ng-click="move(1)" class="btn btn-default btn-sm pull-right" type="button">
<i class="fa fa-chevron-right">
</i>
</button>
</th>
</tr>
<tr class="h6" ng-show="labels.length & gt; 0">
<th class="text-center" ng-show="showWeekNumbers">#</th>
<!-- ngRepeat: label in labels -->
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Sun</th>
<!-- end ngRepeat: label in labels -->
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Mon</th>
<!-- end ngRepeat: label in labels -->
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Tue</th>
<!-- end ngRepeat: label in labels -->
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Wed</th>
<!-- end ngRepeat: label in labels -->
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Thu</th>
<!-- end ngRepeat: label in labels -->
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Fri</th>
<!-- end ngRepeat: label in labels -->
<th class="text-center ng-binding ng-scope" ng-repeat="label in labels">Sat</th>
<!-- end ngRepeat: label in labels -->
</tr>
</thead>
<tbody>
<!-- ngRepeat: row in rows -->
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">17</em>
</td>
<!-- ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">26</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">27</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">28</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">29</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">30</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">01</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">02</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
</tr>
<!-- end ngRepeat: row in rows -->
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">18</em>
</td>
<!-- ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">03</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">04</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">05</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">06</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">07</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">08</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">09</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
</tr>
<!-- end ngRepeat: row in rows -->
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">19</em>
</td>
<!-- ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">10</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">11</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">12</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">13</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">14</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">15</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">16</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
</tr>
<!-- end ngRepeat: row in rows -->
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">20</em>
</td>
<!-- ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">17</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">18</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">19</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">20</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">21</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">22</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">23</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
</tr>
<!-- end ngRepeat: row in rows -->
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">21</em>
</td>
<!-- ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button" disabled="disabled">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">24</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">25</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">26</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">27</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">28</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">29</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">30</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
</tr>
<!-- end ngRepeat: row in rows -->
<tr ng-repeat="row in rows" class="ng-scope">
<td class="text-center" ng-show="showWeekNumbers">
<em class="ng-binding">22</em>
</td>
<!-- ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding">31</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">01</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">02</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">03</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">04</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">05</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
<td class="text-center ng-scope" ng-repeat="dt in row">
<button ng-disabled="dt.disabled" ng-click="select(dt.date)" ng-class="{'btn-info': dt.selected}" class="btn btn-default btn-sm" style="width: 100%" type="button">
<span ng-class="{'text-muted': dt.secondary}" class="ng-binding text-muted">06</span>
</button>
</td>
<!-- end ngRepeat: dt in row -->
</tr>
<!-- end ngRepeat: row in rows -->
</tbody>
</table>
<!-- end calendar to -->                             
                    <input type="hidden" ng-required="schedule.dateEndOption==1" ng-model="schedule.dateEnd" name="dateEnd" class="ng-pristine ng-valid ng-valid-required">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <b>Days</b>
                <div ng-show="schedule.status == 1" class="ng-hide">
                    <p class="small text-muted">Please specify on day range for campaign schedule</p>
                    <!-- ngRepeat: opt in schedule.optionValues -->
                    <div style="cursor:pointer" ng-click="$parent.schedule.option = opt.code" ng-repeat="opt in schedule.optionValues" class="ng-scope">
                        <i ng-class="{'fa-check-square-o':$parent.schedule.option == opt.code,'fa-square-o':$parent.schedule.option != opt.code}" class="fa fa-check-square-o">
                        </i>&nbsp;<span translate="$all_week" class="ng-scope">All Week</span>
                    </div>
                    <!-- end ngRepeat: opt in schedule.optionValues -->
                    <div style="cursor:pointer" ng-click="$parent.schedule.option = opt.code" ng-repeat="opt in schedule.optionValues" class="ng-scope">
                        <i ng-class="{'fa-check-square-o':$parent.schedule.option == opt.code,'fa-square-o':$parent.schedule.option != opt.code}" class="fa fa-square-o">
                        </i>&nbsp;<span translate="$week_days" class="ng-scope">Week days</span>
                    </div>
                    <!-- end ngRepeat: opt in schedule.optionValues -->
                    <div style="cursor:pointer" ng-click="$parent.schedule.option = opt.code" ng-repeat="opt in schedule.optionValues" class="ng-scope">
                        <i ng-class="{'fa-check-square-o':$parent.schedule.option == opt.code,'fa-square-o':$parent.schedule.option != opt.code}" class="fa fa-square-o">
                        </i>&nbsp;<span translate="$weekends" class="ng-scope">Weekends</span>
                    </div>
                    <!-- end ngRepeat: opt in schedule.optionValues -->
                </div>
                <div translate="$all_week" ng-show="schedule.status == 2" class="ng-scope ng-hide">All Week</div>
            </div>
                <div class="col-md-6">
                    <b>Time</b>
                    <p ng-show="schedule.status == 1" class="small text-muted ng-hide">Please specify on time range for campaign schedule</p>
                    <div class="form-group row">
                        <div class="col-sm-6">From
                            <div ng-show="schedule.status == 1" class="ng-hide">
                                <div class="form-group">
                                    <select ng-options="t.code as t.name for t in schedule.timeFromValues" ng-required="schedule.option!=4" ng-model="schedule.scheduleFrom" name="scheduleFrom" class="form-control ng-pristine ng-valid ng-valid-required" required="required">
                                        <option value="" class="">Select</option>
                                        <option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
                                        <option value="1" label="12:30 AM">12:30 AM</option>
                                        <option value="2" label="1:00 AM">1:00 AM</option>
                                        <option value="3" label="1:30 AM">1:30 AM</option>
                                        <option value="4" label="2:00 AM">2:00 AM</option>
                                        <option value="5" label="2:30 AM">2:30 AM</option>
                                        <option value="6" label="3:00 AM">3:00 AM</option>
                                        <option value="7" label="3:30 AM">3:30 AM</option>
                                        <option value="8" label="4:00 AM">4:00 AM</option>
                                        <option value="9" label="4:30 AM">4:30 AM</option>
                                        <option value="10" label="5:00 AM">5:00 AM</option>
                                        <option value="11" label="5:30 AM">5:30 AM</option>
                                        <option value="12" label="6:00 AM">6:00 AM</option>
                                        <option value="13" label="6:30 AM">6:30 AM</option>
                                        <option value="14" label="7:00 AM">7:00 AM</option>
                                        <option value="15" label="7:30 AM">7:30 AM</option>
                                        <option value="16" label="8:00 AM">8:00 AM</option>
                                        <option value="17" label="8:30 AM">8:30 AM</option>
                                        <option value="18" label="9:00 AM">9:00 AM</option>
                                        <option value="19" label="9:30 AM">9:30 AM</option>
                                        <option value="20" label="10:00 AM">10:00 AM</option>
                                        <option value="21" label="10:30 AM">10:30 AM</option>
                                        <option value="22" label="11:00 AM">11:00 AM</option>
                                        <option value="23" label="11:30 AM">11:30 AM</option>
                                        <option value="24" label="12:00 PM">12:00 PM</option>
                                        <option value="25" label="12:30 PM">12:30 PM</option>
                                        <option value="26" label="1:00 PM">1:00 PM</option>
                                        <option value="27" label="1:30 PM">1:30 PM</option>
                                        <option value="28" label="2:00 PM">2:00 PM</option>
                                        <option value="29" label="2:30 PM">2:30 PM</option>
                                        <option value="30" label="3:00 PM">3:00 PM</option>
                                        <option value="31" label="3:30 PM">3:30 PM</option>
                                        <option value="32" label="4:00 PM">4:00 PM</option>
                                        <option value="33" label="4:30 PM">4:30 PM</option>
                                        <option value="34" label="5:00 PM">5:00 PM</option>
                                        <option value="35" label="5:30 PM">5:30 PM</option>
                                        <option value="36" label="6:00 PM">6:00 PM</option>
                                        <option value="37" label="6:30 PM">6:30 PM</option>
                                        <option value="38" label="7:00 PM">7:00 PM</option>
                                        <option value="39" label="7:30 PM">7:30 PM</option>
                                        <option value="40" label="8:00 PM">8:00 PM</option>
                                        <option value="41" label="8:30 PM">8:30 PM</option>
                                        <option value="42" label="9:00 PM">9:00 PM</option>
                                        <option value="43" label="9:30 PM">9:30 PM</option>
                                        <option value="44" label="10:00 PM">10:00 PM</option>
                                        <option value="45" label="10:30 PM">10:30 PM</option>
                                        <option value="46" label="11:00 PM">11:00 PM</option>
                                        <option value="47" label="11:30 PM">11:30 PM</option>
                                    </select>
                                </div>
                                <div ng-show="scheduleForm.scheduleFrom.$error.required & amp; & amp; !scheduleForm.scheduleFrom.$pristine" class="slide-animation text-danger ng-hide">
                                    <i class="fa fa-warning">
                                    </i>&nbsp;<span>From is required</span>
                                </div>
                            </div>
                            <div ng-show="schedule.status == 2" class="ng-binding ng-hide">12:00 AM</div>
                        </div>
                        <div class="col-sm-6">Until
                            <div ng-show="schedule.status == 1" class="ng-hide">
                                <div class="form-group">
                                    <select ng-options="t.code as t.name for t in schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-required="schedule.option!=4" ng-model="schedule.scheduleUntil" name="scheduleUntil" class="form-control ng-pristine ng-valid ng-valid-required" required="required">
                                        <option value="" class="">Select</option>
                                        <option value="0" label="12:30 AM">12:30 AM</option>
                                        <option value="1" label="1:00 AM">1:00 AM</option>
                                        <option value="2" label="1:30 AM">1:30 AM</option>
                                        <option value="3" label="2:00 AM">2:00 AM</option>
                                        <option value="4" label="2:30 AM">2:30 AM</option>
                                        <option value="5" label="3:00 AM">3:00 AM</option>
                                        <option value="6" label="3:30 AM">3:30 AM</option>
                                        <option value="7" label="4:00 AM">4:00 AM</option>
                                        <option value="8" label="4:30 AM">4:30 AM</option>
                                        <option value="9" label="5:00 AM">5:00 AM</option>
                                        <option value="10" label="5:30 AM">5:30 AM</option>
                                        <option value="11" label="6:00 AM">6:00 AM</option>
                                        <option value="12" label="6:30 AM">6:30 AM</option>
                                        <option value="13" label="7:00 AM">7:00 AM</option>
                                        <option value="14" label="7:30 AM">7:30 AM</option>
                                        <option value="15" label="8:00 AM">8:00 AM</option>
                                        <option value="16" label="8:30 AM">8:30 AM</option>
                                        <option value="17" label="9:00 AM">9:00 AM</option>
                                        <option value="18" label="9:30 AM">9:30 AM</option>
                                        <option value="19" label="10:00 AM">10:00 AM</option>
                                        <option value="20" label="10:30 AM">10:30 AM</option>
                                        <option value="21" label="11:00 AM">11:00 AM</option>
                                        <option value="22" label="11:30 AM">11:30 AM</option>
                                        <option value="23" label="12:00 PM">12:00 PM</option>
                                        <option value="24" label="12:30 PM">12:30 PM</option>
                                        <option value="25" label="1:00 PM">1:00 PM</option>
                                        <option value="26" label="1:30 PM">1:30 PM</option>
                                        <option value="27" label="2:00 PM">2:00 PM</option>
                                        <option value="28" label="2:30 PM">2:30 PM</option>
                                        <option value="29" label="3:00 PM">3:00 PM</option>
                                        <option value="30" label="3:30 PM">3:30 PM</option>
                                        <option value="31" label="4:00 PM">4:00 PM</option>
                                        <option value="32" label="4:30 PM">4:30 PM</option>
                                        <option value="33" label="5:00 PM">5:00 PM</option>
                                        <option value="34" label="5:30 PM">5:30 PM</option>
                                        <option value="35" label="6:00 PM">6:00 PM</option>
                                        <option value="36" label="6:30 PM">6:30 PM</option>
                                        <option value="37" label="7:00 PM">7:00 PM</option>
                                        <option value="38" label="7:30 PM">7:30 PM</option>
                                        <option value="39" label="8:00 PM">8:00 PM</option>
                                        <option value="40" label="8:30 PM">8:30 PM</option>
                                        <option value="41" label="9:00 PM">9:00 PM</option>
                                        <option value="42" label="9:30 PM">9:30 PM</option>
                                        <option value="43" label="10:00 PM">10:00 PM</option>
                                        <option value="44" label="10:30 PM">10:30 PM</option>
                                        <option value="45" label="11:00 PM">11:00 PM</option>
                                        <option value="46" label="11:30 PM">11:30 PM</option>
                                        <option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
                                    </select>
                                </div>
                                <div ng-show="scheduleForm.scheduleUntil.$error.required & amp; & amp; !scheduleForm.scheduleUntil.$pristine" class="slide-animation text-danger ng-hide">
                                    <i class="fa fa-warning">
                                    </i>&nbsp;<span>Until is required</span>
                                </div>
                            </div>
                            <div ng-show="schedule.status == 2" class="ng-binding ng-hide">12:00 AM (next day)</div>
                        </div>
                    </div>
                </div>
            </div>
            <div ng-show="schedule.option == 4" class="slide-animation ng-hide">
                <div style="margin-bottom:0" class="panel panel-default panel-content">
<!-- any table -->
                    <table class="table table-stripped">
<thead>
<tr>
<th class="col-sm-3">Day Of Week</th>
<th class="col-sm-3">From</th>
<th class="col-sm-3">Until</th>
<th class="col-sm-3">&nbsp;</th>
</tr>
</thead>
<tbody>
<!-- ngRepeat: schedule in schedule.schedules -->
<tr ng-repeat="schedule in schedule.schedules" class="ng-scope">
<td>
<select ng-options="t.code as (t.name|translate) for t in $parent.schedule.dayValues" ng-model="schedule.dayOfWeek" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="Sunday">Sunday</option>
<option value="1" selected="selected" label="Monday">Monday</option>
<option value="2" label="Tuesday">Tuesday</option>
<option value="3" label="Wednesday">Wednesday</option>
<option value="4" label="Thursday">Thursday</option>
<option value="5" label="Friday">Friday</option>
<option value="6" label="Saturday">Saturday</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeFromValues" ng-model="schedule.from" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
<option value="1" label="12:30 AM">12:30 AM</option>
<option value="2" label="1:00 AM">1:00 AM</option>
<option value="3" label="1:30 AM">1:30 AM</option>
<option value="4" label="2:00 AM">2:00 AM</option>
<option value="5" label="2:30 AM">2:30 AM</option>
<option value="6" label="3:00 AM">3:00 AM</option>
<option value="7" label="3:30 AM">3:30 AM</option>
<option value="8" label="4:00 AM">4:00 AM</option>
<option value="9" label="4:30 AM">4:30 AM</option>
<option value="10" label="5:00 AM">5:00 AM</option>
<option value="11" label="5:30 AM">5:30 AM</option>
<option value="12" label="6:00 AM">6:00 AM</option>
<option value="13" label="6:30 AM">6:30 AM</option>
<option value="14" label="7:00 AM">7:00 AM</option>
<option value="15" label="7:30 AM">7:30 AM</option>
<option value="16" label="8:00 AM">8:00 AM</option>
<option value="17" label="8:30 AM">8:30 AM</option>
<option value="18" label="9:00 AM">9:00 AM</option>
<option value="19" label="9:30 AM">9:30 AM</option>
<option value="20" label="10:00 AM">10:00 AM</option>
<option value="21" label="10:30 AM">10:30 AM</option>
<option value="22" label="11:00 AM">11:00 AM</option>
<option value="23" label="11:30 AM">11:30 AM</option>
<option value="24" label="12:00 PM">12:00 PM</option>
<option value="25" label="12:30 PM">12:30 PM</option>
<option value="26" label="1:00 PM">1:00 PM</option>
<option value="27" label="1:30 PM">1:30 PM</option>
<option value="28" label="2:00 PM">2:00 PM</option>
<option value="29" label="2:30 PM">2:30 PM</option>
<option value="30" label="3:00 PM">3:00 PM</option>
<option value="31" label="3:30 PM">3:30 PM</option>
<option value="32" label="4:00 PM">4:00 PM</option>
<option value="33" label="4:30 PM">4:30 PM</option>
<option value="34" label="5:00 PM">5:00 PM</option>
<option value="35" label="5:30 PM">5:30 PM</option>
<option value="36" label="6:00 PM">6:00 PM</option>
<option value="37" label="6:30 PM">6:30 PM</option>
<option value="38" label="7:00 PM">7:00 PM</option>
<option value="39" label="7:30 PM">7:30 PM</option>
<option value="40" label="8:00 PM">8:00 PM</option>
<option value="41" label="8:30 PM">8:30 PM</option>
<option value="42" label="9:00 PM">9:00 PM</option>
<option value="43" label="9:30 PM">9:30 PM</option>
<option value="44" label="10:00 PM">10:00 PM</option>
<option value="45" label="10:30 PM">10:30 PM</option>
<option value="46" label="11:00 PM">11:00 PM</option>
<option value="47" label="11:30 PM">11:30 PM</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-model="schedule.until" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="12:30 AM">12:30 AM</option>
<option value="1" label="1:00 AM">1:00 AM</option>
<option value="2" label="1:30 AM">1:30 AM</option>
<option value="3" label="2:00 AM">2:00 AM</option>
<option value="4" label="2:30 AM">2:30 AM</option>
<option value="5" label="3:00 AM">3:00 AM</option>
<option value="6" label="3:30 AM">3:30 AM</option>
<option value="7" label="4:00 AM">4:00 AM</option>
<option value="8" label="4:30 AM">4:30 AM</option>
<option value="9" label="5:00 AM">5:00 AM</option>
<option value="10" label="5:30 AM">5:30 AM</option>
<option value="11" label="6:00 AM">6:00 AM</option>
<option value="12" label="6:30 AM">6:30 AM</option>
<option value="13" label="7:00 AM">7:00 AM</option>
<option value="14" label="7:30 AM">7:30 AM</option>
<option value="15" label="8:00 AM">8:00 AM</option>
<option value="16" label="8:30 AM">8:30 AM</option>
<option value="17" label="9:00 AM">9:00 AM</option>
<option value="18" label="9:30 AM">9:30 AM</option>
<option value="19" label="10:00 AM">10:00 AM</option>
<option value="20" label="10:30 AM">10:30 AM</option>
<option value="21" label="11:00 AM">11:00 AM</option>
<option value="22" label="11:30 AM">11:30 AM</option>
<option value="23" label="12:00 PM">12:00 PM</option>
<option value="24" label="12:30 PM">12:30 PM</option>
<option value="25" label="1:00 PM">1:00 PM</option>
<option value="26" label="1:30 PM">1:30 PM</option>
<option value="27" label="2:00 PM">2:00 PM</option>
<option value="28" label="2:30 PM">2:30 PM</option>
<option value="29" label="3:00 PM">3:00 PM</option>
<option value="30" label="3:30 PM">3:30 PM</option>
<option value="31" label="4:00 PM">4:00 PM</option>
<option value="32" label="4:30 PM">4:30 PM</option>
<option value="33" label="5:00 PM">5:00 PM</option>
<option value="34" label="5:30 PM">5:30 PM</option>
<option value="35" label="6:00 PM">6:00 PM</option>
<option value="36" label="6:30 PM">6:30 PM</option>
<option value="37" label="7:00 PM">7:00 PM</option>
<option value="38" label="7:30 PM">7:30 PM</option>
<option value="39" label="8:00 PM">8:00 PM</option>
<option value="40" label="8:30 PM">8:30 PM</option>
<option value="41" label="9:00 PM">9:00 PM</option>
<option value="42" label="9:30 PM">9:30 PM</option>
<option value="43" label="10:00 PM">10:00 PM</option>
<option value="44" label="10:30 PM">10:30 PM</option>
<option value="45" label="11:00 PM">11:00 PM</option>
<option value="46" label="11:30 PM">11:30 PM</option>
<option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
</select>
</td>
<td>
<button ng-click="$parent.schedule.scheduleRemove($index)" class="form-control btn btn-primary">
<i class="fa fa-times">
</i>&nbsp;Remove</button>
</td>
</tr>
<!-- end ngRepeat: schedule in schedule.schedules -->
<tr ng-repeat="schedule in schedule.schedules" class="ng-scope">
<td>
<select ng-options="t.code as (t.name|translate) for t in $parent.schedule.dayValues" ng-model="schedule.dayOfWeek" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="Sunday">Sunday</option>
<option value="1" label="Monday">Monday</option>
<option value="2" selected="selected" label="Tuesday">Tuesday</option>
<option value="3" label="Wednesday">Wednesday</option>
<option value="4" label="Thursday">Thursday</option>
<option value="5" label="Friday">Friday</option>
<option value="6" label="Saturday">Saturday</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeFromValues" ng-model="schedule.from" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
<option value="1" label="12:30 AM">12:30 AM</option>
<option value="2" label="1:00 AM">1:00 AM</option>
<option value="3" label="1:30 AM">1:30 AM</option>
<option value="4" label="2:00 AM">2:00 AM</option>
<option value="5" label="2:30 AM">2:30 AM</option>
<option value="6" label="3:00 AM">3:00 AM</option>
<option value="7" label="3:30 AM">3:30 AM</option>
<option value="8" label="4:00 AM">4:00 AM</option>
<option value="9" label="4:30 AM">4:30 AM</option>
<option value="10" label="5:00 AM">5:00 AM</option>
<option value="11" label="5:30 AM">5:30 AM</option>
<option value="12" label="6:00 AM">6:00 AM</option>
<option value="13" label="6:30 AM">6:30 AM</option>
<option value="14" label="7:00 AM">7:00 AM</option>
<option value="15" label="7:30 AM">7:30 AM</option>
<option value="16" label="8:00 AM">8:00 AM</option>
<option value="17" label="8:30 AM">8:30 AM</option>
<option value="18" label="9:00 AM">9:00 AM</option>
<option value="19" label="9:30 AM">9:30 AM</option>
<option value="20" label="10:00 AM">10:00 AM</option>
<option value="21" label="10:30 AM">10:30 AM</option>
<option value="22" label="11:00 AM">11:00 AM</option>
<option value="23" label="11:30 AM">11:30 AM</option>
<option value="24" label="12:00 PM">12:00 PM</option>
<option value="25" label="12:30 PM">12:30 PM</option>
<option value="26" label="1:00 PM">1:00 PM</option>
<option value="27" label="1:30 PM">1:30 PM</option>
<option value="28" label="2:00 PM">2:00 PM</option>
<option value="29" label="2:30 PM">2:30 PM</option>
<option value="30" label="3:00 PM">3:00 PM</option>
<option value="31" label="3:30 PM">3:30 PM</option>
<option value="32" label="4:00 PM">4:00 PM</option>
<option value="33" label="4:30 PM">4:30 PM</option>
<option value="34" label="5:00 PM">5:00 PM</option>
<option value="35" label="5:30 PM">5:30 PM</option>
<option value="36" label="6:00 PM">6:00 PM</option>
<option value="37" label="6:30 PM">6:30 PM</option>
<option value="38" label="7:00 PM">7:00 PM</option>
<option value="39" label="7:30 PM">7:30 PM</option>
<option value="40" label="8:00 PM">8:00 PM</option>
<option value="41" label="8:30 PM">8:30 PM</option>
<option value="42" label="9:00 PM">9:00 PM</option>
<option value="43" label="9:30 PM">9:30 PM</option>
<option value="44" label="10:00 PM">10:00 PM</option>
<option value="45" label="10:30 PM">10:30 PM</option>
<option value="46" label="11:00 PM">11:00 PM</option>
<option value="47" label="11:30 PM">11:30 PM</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-model="schedule.until" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="12:30 AM">12:30 AM</option>
<option value="1" label="1:00 AM">1:00 AM</option>
<option value="2" label="1:30 AM">1:30 AM</option>
<option value="3" label="2:00 AM">2:00 AM</option>
<option value="4" label="2:30 AM">2:30 AM</option>
<option value="5" label="3:00 AM">3:00 AM</option>
<option value="6" label="3:30 AM">3:30 AM</option>
<option value="7" label="4:00 AM">4:00 AM</option>
<option value="8" label="4:30 AM">4:30 AM</option>
<option value="9" label="5:00 AM">5:00 AM</option>
<option value="10" label="5:30 AM">5:30 AM</option>
<option value="11" label="6:00 AM">6:00 AM</option>
<option value="12" label="6:30 AM">6:30 AM</option>
<option value="13" label="7:00 AM">7:00 AM</option>
<option value="14" label="7:30 AM">7:30 AM</option>
<option value="15" label="8:00 AM">8:00 AM</option>
<option value="16" label="8:30 AM">8:30 AM</option>
<option value="17" label="9:00 AM">9:00 AM</option>
<option value="18" label="9:30 AM">9:30 AM</option>
<option value="19" label="10:00 AM">10:00 AM</option>
<option value="20" label="10:30 AM">10:30 AM</option>
<option value="21" label="11:00 AM">11:00 AM</option>
<option value="22" label="11:30 AM">11:30 AM</option>
<option value="23" label="12:00 PM">12:00 PM</option>
<option value="24" label="12:30 PM">12:30 PM</option>
<option value="25" label="1:00 PM">1:00 PM</option>
<option value="26" label="1:30 PM">1:30 PM</option>
<option value="27" label="2:00 PM">2:00 PM</option>
<option value="28" label="2:30 PM">2:30 PM</option>
<option value="29" label="3:00 PM">3:00 PM</option>
<option value="30" label="3:30 PM">3:30 PM</option>
<option value="31" label="4:00 PM">4:00 PM</option>
<option value="32" label="4:30 PM">4:30 PM</option>
<option value="33" label="5:00 PM">5:00 PM</option>
<option value="34" label="5:30 PM">5:30 PM</option>
<option value="35" label="6:00 PM">6:00 PM</option>
<option value="36" label="6:30 PM">6:30 PM</option>
<option value="37" label="7:00 PM">7:00 PM</option>
<option value="38" label="7:30 PM">7:30 PM</option>
<option value="39" label="8:00 PM">8:00 PM</option>
<option value="40" label="8:30 PM">8:30 PM</option>
<option value="41" label="9:00 PM">9:00 PM</option>
<option value="42" label="9:30 PM">9:30 PM</option>
<option value="43" label="10:00 PM">10:00 PM</option>
<option value="44" label="10:30 PM">10:30 PM</option>
<option value="45" label="11:00 PM">11:00 PM</option>
<option value="46" label="11:30 PM">11:30 PM</option>
<option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
</select>
</td>
<td>
<button ng-click="$parent.schedule.scheduleRemove($index)" class="form-control btn btn-primary">
<i class="fa fa-times">
</i>&nbsp;Remove</button>
</td>
</tr>
<!-- end ngRepeat: schedule in schedule.schedules -->
<tr ng-repeat="schedule in schedule.schedules" class="ng-scope">
<td>
<select ng-options="t.code as (t.name|translate) for t in $parent.schedule.dayValues" ng-model="schedule.dayOfWeek" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="Sunday">Sunday</option>
<option value="1" label="Monday">Monday</option>
<option value="2" label="Tuesday">Tuesday</option>
<option value="3" selected="selected" label="Wednesday">Wednesday</option>
<option value="4" label="Thursday">Thursday</option>
<option value="5" label="Friday">Friday</option>
<option value="6" label="Saturday">Saturday</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeFromValues" ng-model="schedule.from" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
<option value="1" label="12:30 AM">12:30 AM</option>
<option value="2" label="1:00 AM">1:00 AM</option>
<option value="3" label="1:30 AM">1:30 AM</option>
<option value="4" label="2:00 AM">2:00 AM</option>
<option value="5" label="2:30 AM">2:30 AM</option>
<option value="6" label="3:00 AM">3:00 AM</option>
<option value="7" label="3:30 AM">3:30 AM</option>
<option value="8" label="4:00 AM">4:00 AM</option>
<option value="9" label="4:30 AM">4:30 AM</option>
<option value="10" label="5:00 AM">5:00 AM</option>
<option value="11" label="5:30 AM">5:30 AM</option>
<option value="12" label="6:00 AM">6:00 AM</option>
<option value="13" label="6:30 AM">6:30 AM</option>
<option value="14" label="7:00 AM">7:00 AM</option>
<option value="15" label="7:30 AM">7:30 AM</option>
<option value="16" label="8:00 AM">8:00 AM</option>
<option value="17" label="8:30 AM">8:30 AM</option>
<option value="18" label="9:00 AM">9:00 AM</option>
<option value="19" label="9:30 AM">9:30 AM</option>
<option value="20" label="10:00 AM">10:00 AM</option>
<option value="21" label="10:30 AM">10:30 AM</option>
<option value="22" label="11:00 AM">11:00 AM</option>
<option value="23" label="11:30 AM">11:30 AM</option>
<option value="24" label="12:00 PM">12:00 PM</option>
<option value="25" label="12:30 PM">12:30 PM</option>
<option value="26" label="1:00 PM">1:00 PM</option>
<option value="27" label="1:30 PM">1:30 PM</option>
<option value="28" label="2:00 PM">2:00 PM</option>
<option value="29" label="2:30 PM">2:30 PM</option>
<option value="30" label="3:00 PM">3:00 PM</option>
<option value="31" label="3:30 PM">3:30 PM</option>
<option value="32" label="4:00 PM">4:00 PM</option>
<option value="33" label="4:30 PM">4:30 PM</option>
<option value="34" label="5:00 PM">5:00 PM</option>
<option value="35" label="5:30 PM">5:30 PM</option>
<option value="36" label="6:00 PM">6:00 PM</option>
<option value="37" label="6:30 PM">6:30 PM</option>
<option value="38" label="7:00 PM">7:00 PM</option>
<option value="39" label="7:30 PM">7:30 PM</option>
<option value="40" label="8:00 PM">8:00 PM</option>
<option value="41" label="8:30 PM">8:30 PM</option>
<option value="42" label="9:00 PM">9:00 PM</option>
<option value="43" label="9:30 PM">9:30 PM</option>
<option value="44" label="10:00 PM">10:00 PM</option>
<option value="45" label="10:30 PM">10:30 PM</option>
<option value="46" label="11:00 PM">11:00 PM</option>
<option value="47" label="11:30 PM">11:30 PM</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-model="schedule.until" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="12:30 AM">12:30 AM</option>
<option value="1" label="1:00 AM">1:00 AM</option>
<option value="2" label="1:30 AM">1:30 AM</option>
<option value="3" label="2:00 AM">2:00 AM</option>
<option value="4" label="2:30 AM">2:30 AM</option>
<option value="5" label="3:00 AM">3:00 AM</option>
<option value="6" label="3:30 AM">3:30 AM</option>
<option value="7" label="4:00 AM">4:00 AM</option>
<option value="8" label="4:30 AM">4:30 AM</option>
<option value="9" label="5:00 AM">5:00 AM</option>
<option value="10" label="5:30 AM">5:30 AM</option>
<option value="11" label="6:00 AM">6:00 AM</option>
<option value="12" label="6:30 AM">6:30 AM</option>
<option value="13" label="7:00 AM">7:00 AM</option>
<option value="14" label="7:30 AM">7:30 AM</option>
<option value="15" label="8:00 AM">8:00 AM</option>
<option value="16" label="8:30 AM">8:30 AM</option>
<option value="17" label="9:00 AM">9:00 AM</option>
<option value="18" label="9:30 AM">9:30 AM</option>
<option value="19" label="10:00 AM">10:00 AM</option>
<option value="20" label="10:30 AM">10:30 AM</option>
<option value="21" label="11:00 AM">11:00 AM</option>
<option value="22" label="11:30 AM">11:30 AM</option>
<option value="23" label="12:00 PM">12:00 PM</option>
<option value="24" label="12:30 PM">12:30 PM</option>
<option value="25" label="1:00 PM">1:00 PM</option>
<option value="26" label="1:30 PM">1:30 PM</option>
<option value="27" label="2:00 PM">2:00 PM</option>
<option value="28" label="2:30 PM">2:30 PM</option>
<option value="29" label="3:00 PM">3:00 PM</option>
<option value="30" label="3:30 PM">3:30 PM</option>
<option value="31" label="4:00 PM">4:00 PM</option>
<option value="32" label="4:30 PM">4:30 PM</option>
<option value="33" label="5:00 PM">5:00 PM</option>
<option value="34" label="5:30 PM">5:30 PM</option>
<option value="35" label="6:00 PM">6:00 PM</option>
<option value="36" label="6:30 PM">6:30 PM</option>
<option value="37" label="7:00 PM">7:00 PM</option>
<option value="38" label="7:30 PM">7:30 PM</option>
<option value="39" label="8:00 PM">8:00 PM</option>
<option value="40" label="8:30 PM">8:30 PM</option>
<option value="41" label="9:00 PM">9:00 PM</option>
<option value="42" label="9:30 PM">9:30 PM</option>
<option value="43" label="10:00 PM">10:00 PM</option>
<option value="44" label="10:30 PM">10:30 PM</option>
<option value="45" label="11:00 PM">11:00 PM</option>
<option value="46" label="11:30 PM">11:30 PM</option>
<option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
</select>
</td>
<td>
<button ng-click="$parent.schedule.scheduleRemove($index)" class="form-control btn btn-primary">
<i class="fa fa-times">
</i>&nbsp;Remove</button>
</td>
</tr>
<!-- end ngRepeat: schedule in schedule.schedules -->
<tr ng-repeat="schedule in schedule.schedules" class="ng-scope">
<td>
<select ng-options="t.code as (t.name|translate) for t in $parent.schedule.dayValues" ng-model="schedule.dayOfWeek" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="Sunday">Sunday</option>
<option value="1" label="Monday">Monday</option>
<option value="2" label="Tuesday">Tuesday</option>
<option value="3" label="Wednesday">Wednesday</option>
<option value="4" selected="selected" label="Thursday">Thursday</option>
<option value="5" label="Friday">Friday</option>
<option value="6" label="Saturday">Saturday</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeFromValues" ng-model="schedule.from" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
<option value="1" label="12:30 AM">12:30 AM</option>
<option value="2" label="1:00 AM">1:00 AM</option>
<option value="3" label="1:30 AM">1:30 AM</option>
<option value="4" label="2:00 AM">2:00 AM</option>
<option value="5" label="2:30 AM">2:30 AM</option>
<option value="6" label="3:00 AM">3:00 AM</option>
<option value="7" label="3:30 AM">3:30 AM</option>
<option value="8" label="4:00 AM">4:00 AM</option>
<option value="9" label="4:30 AM">4:30 AM</option>
<option value="10" label="5:00 AM">5:00 AM</option>
<option value="11" label="5:30 AM">5:30 AM</option>
<option value="12" label="6:00 AM">6:00 AM</option>
<option value="13" label="6:30 AM">6:30 AM</option>
<option value="14" label="7:00 AM">7:00 AM</option>
<option value="15" label="7:30 AM">7:30 AM</option>
<option value="16" label="8:00 AM">8:00 AM</option>
<option value="17" label="8:30 AM">8:30 AM</option>
<option value="18" label="9:00 AM">9:00 AM</option>
<option value="19" label="9:30 AM">9:30 AM</option>
<option value="20" label="10:00 AM">10:00 AM</option>
<option value="21" label="10:30 AM">10:30 AM</option>
<option value="22" label="11:00 AM">11:00 AM</option>
<option value="23" label="11:30 AM">11:30 AM</option>
<option value="24" label="12:00 PM">12:00 PM</option>
<option value="25" label="12:30 PM">12:30 PM</option>
<option value="26" label="1:00 PM">1:00 PM</option>
<option value="27" label="1:30 PM">1:30 PM</option>
<option value="28" label="2:00 PM">2:00 PM</option>
<option value="29" label="2:30 PM">2:30 PM</option>
<option value="30" label="3:00 PM">3:00 PM</option>
<option value="31" label="3:30 PM">3:30 PM</option>
<option value="32" label="4:00 PM">4:00 PM</option>
<option value="33" label="4:30 PM">4:30 PM</option>
<option value="34" label="5:00 PM">5:00 PM</option>
<option value="35" label="5:30 PM">5:30 PM</option>
<option value="36" label="6:00 PM">6:00 PM</option>
<option value="37" label="6:30 PM">6:30 PM</option>
<option value="38" label="7:00 PM">7:00 PM</option>
<option value="39" label="7:30 PM">7:30 PM</option>
<option value="40" label="8:00 PM">8:00 PM</option>
<option value="41" label="8:30 PM">8:30 PM</option>
<option value="42" label="9:00 PM">9:00 PM</option>
<option value="43" label="9:30 PM">9:30 PM</option>
<option value="44" label="10:00 PM">10:00 PM</option>
<option value="45" label="10:30 PM">10:30 PM</option>
<option value="46" label="11:00 PM">11:00 PM</option>
<option value="47" label="11:30 PM">11:30 PM</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-model="schedule.until" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="12:30 AM">12:30 AM</option>
<option value="1" label="1:00 AM">1:00 AM</option>
<option value="2" label="1:30 AM">1:30 AM</option>
<option value="3" label="2:00 AM">2:00 AM</option>
<option value="4" label="2:30 AM">2:30 AM</option>
<option value="5" label="3:00 AM">3:00 AM</option>
<option value="6" label="3:30 AM">3:30 AM</option>
<option value="7" label="4:00 AM">4:00 AM</option>
<option value="8" label="4:30 AM">4:30 AM</option>
<option value="9" label="5:00 AM">5:00 AM</option>
<option value="10" label="5:30 AM">5:30 AM</option>
<option value="11" label="6:00 AM">6:00 AM</option>
<option value="12" label="6:30 AM">6:30 AM</option>
<option value="13" label="7:00 AM">7:00 AM</option>
<option value="14" label="7:30 AM">7:30 AM</option>
<option value="15" label="8:00 AM">8:00 AM</option>
<option value="16" label="8:30 AM">8:30 AM</option>
<option value="17" label="9:00 AM">9:00 AM</option>
<option value="18" label="9:30 AM">9:30 AM</option>
<option value="19" label="10:00 AM">10:00 AM</option>
<option value="20" label="10:30 AM">10:30 AM</option>
<option value="21" label="11:00 AM">11:00 AM</option>
<option value="22" label="11:30 AM">11:30 AM</option>
<option value="23" label="12:00 PM">12:00 PM</option>
<option value="24" label="12:30 PM">12:30 PM</option>
<option value="25" label="1:00 PM">1:00 PM</option>
<option value="26" label="1:30 PM">1:30 PM</option>
<option value="27" label="2:00 PM">2:00 PM</option>
<option value="28" label="2:30 PM">2:30 PM</option>
<option value="29" label="3:00 PM">3:00 PM</option>
<option value="30" label="3:30 PM">3:30 PM</option>
<option value="31" label="4:00 PM">4:00 PM</option>
<option value="32" label="4:30 PM">4:30 PM</option>
<option value="33" label="5:00 PM">5:00 PM</option>
<option value="34" label="5:30 PM">5:30 PM</option>
<option value="35" label="6:00 PM">6:00 PM</option>
<option value="36" label="6:30 PM">6:30 PM</option>
<option value="37" label="7:00 PM">7:00 PM</option>
<option value="38" label="7:30 PM">7:30 PM</option>
<option value="39" label="8:00 PM">8:00 PM</option>
<option value="40" label="8:30 PM">8:30 PM</option>
<option value="41" label="9:00 PM">9:00 PM</option>
<option value="42" label="9:30 PM">9:30 PM</option>
<option value="43" label="10:00 PM">10:00 PM</option>
<option value="44" label="10:30 PM">10:30 PM</option>
<option value="45" label="11:00 PM">11:00 PM</option>
<option value="46" label="11:30 PM">11:30 PM</option>
<option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
</select>
</td>
<td>
<button ng-click="$parent.schedule.scheduleRemove($index)" class="form-control btn btn-primary">
<i class="fa fa-times">
</i>&nbsp;Remove</button>
</td>
</tr>
<!-- end ngRepeat: schedule in schedule.schedules -->
<tr ng-repeat="schedule in schedule.schedules" class="ng-scope">
<td>
<select ng-options="t.code as (t.name|translate) for t in $parent.schedule.dayValues" ng-model="schedule.dayOfWeek" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="Sunday">Sunday</option>
<option value="1" label="Monday">Monday</option>
<option value="2" label="Tuesday">Tuesday</option>
<option value="3" label="Wednesday">Wednesday</option>
<option value="4" label="Thursday">Thursday</option>
<option value="5" selected="selected" label="Friday">Friday</option>
<option value="6" label="Saturday">Saturday</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeFromValues" ng-model="schedule.from" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
<option value="1" label="12:30 AM">12:30 AM</option>
<option value="2" label="1:00 AM">1:00 AM</option>
<option value="3" label="1:30 AM">1:30 AM</option>
<option value="4" label="2:00 AM">2:00 AM</option>
<option value="5" label="2:30 AM">2:30 AM</option>
<option value="6" label="3:00 AM">3:00 AM</option>
<option value="7" label="3:30 AM">3:30 AM</option>
<option value="8" label="4:00 AM">4:00 AM</option>
<option value="9" label="4:30 AM">4:30 AM</option>
<option value="10" label="5:00 AM">5:00 AM</option>
<option value="11" label="5:30 AM">5:30 AM</option>
<option value="12" label="6:00 AM">6:00 AM</option>
<option value="13" label="6:30 AM">6:30 AM</option>
<option value="14" label="7:00 AM">7:00 AM</option>
<option value="15" label="7:30 AM">7:30 AM</option>
<option value="16" label="8:00 AM">8:00 AM</option>
<option value="17" label="8:30 AM">8:30 AM</option>
<option value="18" label="9:00 AM">9:00 AM</option>
<option value="19" label="9:30 AM">9:30 AM</option>
<option value="20" label="10:00 AM">10:00 AM</option>
<option value="21" label="10:30 AM">10:30 AM</option>
<option value="22" label="11:00 AM">11:00 AM</option>
<option value="23" label="11:30 AM">11:30 AM</option>
<option value="24" label="12:00 PM">12:00 PM</option>
<option value="25" label="12:30 PM">12:30 PM</option>
<option value="26" label="1:00 PM">1:00 PM</option>
<option value="27" label="1:30 PM">1:30 PM</option>
<option value="28" label="2:00 PM">2:00 PM</option>
<option value="29" label="2:30 PM">2:30 PM</option>
<option value="30" label="3:00 PM">3:00 PM</option>
<option value="31" label="3:30 PM">3:30 PM</option>
<option value="32" label="4:00 PM">4:00 PM</option>
<option value="33" label="4:30 PM">4:30 PM</option>
<option value="34" label="5:00 PM">5:00 PM</option>
<option value="35" label="5:30 PM">5:30 PM</option>
<option value="36" label="6:00 PM">6:00 PM</option>
<option value="37" label="6:30 PM">6:30 PM</option>
<option value="38" label="7:00 PM">7:00 PM</option>
<option value="39" label="7:30 PM">7:30 PM</option>
<option value="40" label="8:00 PM">8:00 PM</option>
<option value="41" label="8:30 PM">8:30 PM</option>
<option value="42" label="9:00 PM">9:00 PM</option>
<option value="43" label="9:30 PM">9:30 PM</option>
<option value="44" label="10:00 PM">10:00 PM</option>
<option value="45" label="10:30 PM">10:30 PM</option>
<option value="46" label="11:00 PM">11:00 PM</option>
<option value="47" label="11:30 PM">11:30 PM</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-model="schedule.until" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="12:30 AM">12:30 AM</option>
<option value="1" label="1:00 AM">1:00 AM</option>
<option value="2" label="1:30 AM">1:30 AM</option>
<option value="3" label="2:00 AM">2:00 AM</option>
<option value="4" label="2:30 AM">2:30 AM</option>
<option value="5" label="3:00 AM">3:00 AM</option>
<option value="6" label="3:30 AM">3:30 AM</option>
<option value="7" label="4:00 AM">4:00 AM</option>
<option value="8" label="4:30 AM">4:30 AM</option>
<option value="9" label="5:00 AM">5:00 AM</option>
<option value="10" label="5:30 AM">5:30 AM</option>
<option value="11" label="6:00 AM">6:00 AM</option>
<option value="12" label="6:30 AM">6:30 AM</option>
<option value="13" label="7:00 AM">7:00 AM</option>
<option value="14" label="7:30 AM">7:30 AM</option>
<option value="15" label="8:00 AM">8:00 AM</option>
<option value="16" label="8:30 AM">8:30 AM</option>
<option value="17" label="9:00 AM">9:00 AM</option>
<option value="18" label="9:30 AM">9:30 AM</option>
<option value="19" label="10:00 AM">10:00 AM</option>
<option value="20" label="10:30 AM">10:30 AM</option>
<option value="21" label="11:00 AM">11:00 AM</option>
<option value="22" label="11:30 AM">11:30 AM</option>
<option value="23" label="12:00 PM">12:00 PM</option>
<option value="24" label="12:30 PM">12:30 PM</option>
<option value="25" label="1:00 PM">1:00 PM</option>
<option value="26" label="1:30 PM">1:30 PM</option>
<option value="27" label="2:00 PM">2:00 PM</option>
<option value="28" label="2:30 PM">2:30 PM</option>
<option value="29" label="3:00 PM">3:00 PM</option>
<option value="30" label="3:30 PM">3:30 PM</option>
<option value="31" label="4:00 PM">4:00 PM</option>
<option value="32" label="4:30 PM">4:30 PM</option>
<option value="33" label="5:00 PM">5:00 PM</option>
<option value="34" label="5:30 PM">5:30 PM</option>
<option value="35" label="6:00 PM">6:00 PM</option>
<option value="36" label="6:30 PM">6:30 PM</option>
<option value="37" label="7:00 PM">7:00 PM</option>
<option value="38" label="7:30 PM">7:30 PM</option>
<option value="39" label="8:00 PM">8:00 PM</option>
<option value="40" label="8:30 PM">8:30 PM</option>
<option value="41" label="9:00 PM">9:00 PM</option>
<option value="42" label="9:30 PM">9:30 PM</option>
<option value="43" label="10:00 PM">10:00 PM</option>
<option value="44" label="10:30 PM">10:30 PM</option>
<option value="45" label="11:00 PM">11:00 PM</option>
<option value="46" label="11:30 PM">11:30 PM</option>
<option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
</select>
</td>
<td>
<button ng-click="$parent.schedule.scheduleRemove($index)" class="form-control btn btn-primary">
<i class="fa fa-times">
</i>&nbsp;Remove</button>
</td>
</tr>
<!-- end ngRepeat: schedule in schedule.schedules -->
<tr ng-repeat="schedule in schedule.schedules" class="ng-scope">
<td>
<select ng-options="t.code as (t.name|translate) for t in $parent.schedule.dayValues" ng-model="schedule.dayOfWeek" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="Sunday">Sunday</option>
<option value="1" label="Monday">Monday</option>
<option value="2" label="Tuesday">Tuesday</option>
<option value="3" label="Wednesday">Wednesday</option>
<option value="4" label="Thursday">Thursday</option>
<option value="5" label="Friday">Friday</option>
<option value="6" selected="selected" label="Saturday">Saturday</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeFromValues" ng-model="schedule.from" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
<option value="1" label="12:30 AM">12:30 AM</option>
<option value="2" label="1:00 AM">1:00 AM</option>
<option value="3" label="1:30 AM">1:30 AM</option>
<option value="4" label="2:00 AM">2:00 AM</option>
<option value="5" label="2:30 AM">2:30 AM</option>
<option value="6" label="3:00 AM">3:00 AM</option>
<option value="7" label="3:30 AM">3:30 AM</option>
<option value="8" label="4:00 AM">4:00 AM</option>
<option value="9" label="4:30 AM">4:30 AM</option>
<option value="10" label="5:00 AM">5:00 AM</option>
<option value="11" label="5:30 AM">5:30 AM</option>
<option value="12" label="6:00 AM">6:00 AM</option>
<option value="13" label="6:30 AM">6:30 AM</option>
<option value="14" label="7:00 AM">7:00 AM</option>
<option value="15" label="7:30 AM">7:30 AM</option>
<option value="16" label="8:00 AM">8:00 AM</option>
<option value="17" label="8:30 AM">8:30 AM</option>
<option value="18" label="9:00 AM">9:00 AM</option>
<option value="19" label="9:30 AM">9:30 AM</option>
<option value="20" label="10:00 AM">10:00 AM</option>
<option value="21" label="10:30 AM">10:30 AM</option>
<option value="22" label="11:00 AM">11:00 AM</option>
<option value="23" label="11:30 AM">11:30 AM</option>
<option value="24" label="12:00 PM">12:00 PM</option>
<option value="25" label="12:30 PM">12:30 PM</option>
<option value="26" label="1:00 PM">1:00 PM</option>
<option value="27" label="1:30 PM">1:30 PM</option>
<option value="28" label="2:00 PM">2:00 PM</option>
<option value="29" label="2:30 PM">2:30 PM</option>
<option value="30" label="3:00 PM">3:00 PM</option>
<option value="31" label="3:30 PM">3:30 PM</option>
<option value="32" label="4:00 PM">4:00 PM</option>
<option value="33" label="4:30 PM">4:30 PM</option>
<option value="34" label="5:00 PM">5:00 PM</option>
<option value="35" label="5:30 PM">5:30 PM</option>
<option value="36" label="6:00 PM">6:00 PM</option>
<option value="37" label="6:30 PM">6:30 PM</option>
<option value="38" label="7:00 PM">7:00 PM</option>
<option value="39" label="7:30 PM">7:30 PM</option>
<option value="40" label="8:00 PM">8:00 PM</option>
<option value="41" label="8:30 PM">8:30 PM</option>
<option value="42" label="9:00 PM">9:00 PM</option>
<option value="43" label="9:30 PM">9:30 PM</option>
<option value="44" label="10:00 PM">10:00 PM</option>
<option value="45" label="10:30 PM">10:30 PM</option>
<option value="46" label="11:00 PM">11:00 PM</option>
<option value="47" label="11:30 PM">11:30 PM</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-model="schedule.until" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="12:30 AM">12:30 AM</option>
<option value="1" label="1:00 AM">1:00 AM</option>
<option value="2" label="1:30 AM">1:30 AM</option>
<option value="3" label="2:00 AM">2:00 AM</option>
<option value="4" label="2:30 AM">2:30 AM</option>
<option value="5" label="3:00 AM">3:00 AM</option>
<option value="6" label="3:30 AM">3:30 AM</option>
<option value="7" label="4:00 AM">4:00 AM</option>
<option value="8" label="4:30 AM">4:30 AM</option>
<option value="9" label="5:00 AM">5:00 AM</option>
<option value="10" label="5:30 AM">5:30 AM</option>
<option value="11" label="6:00 AM">6:00 AM</option>
<option value="12" label="6:30 AM">6:30 AM</option>
<option value="13" label="7:00 AM">7:00 AM</option>
<option value="14" label="7:30 AM">7:30 AM</option>
<option value="15" label="8:00 AM">8:00 AM</option>
<option value="16" label="8:30 AM">8:30 AM</option>
<option value="17" label="9:00 AM">9:00 AM</option>
<option value="18" label="9:30 AM">9:30 AM</option>
<option value="19" label="10:00 AM">10:00 AM</option>
<option value="20" label="10:30 AM">10:30 AM</option>
<option value="21" label="11:00 AM">11:00 AM</option>
<option value="22" label="11:30 AM">11:30 AM</option>
<option value="23" label="12:00 PM">12:00 PM</option>
<option value="24" label="12:30 PM">12:30 PM</option>
<option value="25" label="1:00 PM">1:00 PM</option>
<option value="26" label="1:30 PM">1:30 PM</option>
<option value="27" label="2:00 PM">2:00 PM</option>
<option value="28" label="2:30 PM">2:30 PM</option>
<option value="29" label="3:00 PM">3:00 PM</option>
<option value="30" label="3:30 PM">3:30 PM</option>
<option value="31" label="4:00 PM">4:00 PM</option>
<option value="32" label="4:30 PM">4:30 PM</option>
<option value="33" label="5:00 PM">5:00 PM</option>
<option value="34" label="5:30 PM">5:30 PM</option>
<option value="35" label="6:00 PM">6:00 PM</option>
<option value="36" label="6:30 PM">6:30 PM</option>
<option value="37" label="7:00 PM">7:00 PM</option>
<option value="38" label="7:30 PM">7:30 PM</option>
<option value="39" label="8:00 PM">8:00 PM</option>
<option value="40" label="8:30 PM">8:30 PM</option>
<option value="41" label="9:00 PM">9:00 PM</option>
<option value="42" label="9:30 PM">9:30 PM</option>
<option value="43" label="10:00 PM">10:00 PM</option>
<option value="44" label="10:30 PM">10:30 PM</option>
<option value="45" label="11:00 PM">11:00 PM</option>
<option value="46" label="11:30 PM">11:30 PM</option>
<option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
</select>
</td>
<td>
<button ng-click="$parent.schedule.scheduleRemove($index)" class="form-control btn btn-primary">
<i class="fa fa-times">
</i>&nbsp;Remove</button>
</td>
</tr>
<!-- end ngRepeat: schedule in schedule.schedules -->
<tr ng-repeat="schedule in schedule.schedules" class="ng-scope">
<td>
<select ng-options="t.code as (t.name|translate) for t in $parent.schedule.dayValues" ng-model="schedule.dayOfWeek" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="Sunday">Sunday</option>
<option value="1" label="Monday">Monday</option>
<option value="2" label="Tuesday">Tuesday</option>
<option value="3" label="Wednesday">Wednesday</option>
<option value="4" label="Thursday">Thursday</option>
<option value="5" label="Friday">Friday</option>
<option value="6" label="Saturday">Saturday</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeFromValues" ng-model="schedule.from" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" selected="selected" label="12:00 AM">12:00 AM</option>
<option value="1" label="12:30 AM">12:30 AM</option>
<option value="2" label="1:00 AM">1:00 AM</option>
<option value="3" label="1:30 AM">1:30 AM</option>
<option value="4" label="2:00 AM">2:00 AM</option>
<option value="5" label="2:30 AM">2:30 AM</option>
<option value="6" label="3:00 AM">3:00 AM</option>
<option value="7" label="3:30 AM">3:30 AM</option>
<option value="8" label="4:00 AM">4:00 AM</option>
<option value="9" label="4:30 AM">4:30 AM</option>
<option value="10" label="5:00 AM">5:00 AM</option>
<option value="11" label="5:30 AM">5:30 AM</option>
<option value="12" label="6:00 AM">6:00 AM</option>
<option value="13" label="6:30 AM">6:30 AM</option>
<option value="14" label="7:00 AM">7:00 AM</option>
<option value="15" label="7:30 AM">7:30 AM</option>
<option value="16" label="8:00 AM">8:00 AM</option>
<option value="17" label="8:30 AM">8:30 AM</option>
<option value="18" label="9:00 AM">9:00 AM</option>
<option value="19" label="9:30 AM">9:30 AM</option>
<option value="20" label="10:00 AM">10:00 AM</option>
<option value="21" label="10:30 AM">10:30 AM</option>
<option value="22" label="11:00 AM">11:00 AM</option>
<option value="23" label="11:30 AM">11:30 AM</option>
<option value="24" label="12:00 PM">12:00 PM</option>
<option value="25" label="12:30 PM">12:30 PM</option>
<option value="26" label="1:00 PM">1:00 PM</option>
<option value="27" label="1:30 PM">1:30 PM</option>
<option value="28" label="2:00 PM">2:00 PM</option>
<option value="29" label="2:30 PM">2:30 PM</option>
<option value="30" label="3:00 PM">3:00 PM</option>
<option value="31" label="3:30 PM">3:30 PM</option>
<option value="32" label="4:00 PM">4:00 PM</option>
<option value="33" label="4:30 PM">4:30 PM</option>
<option value="34" label="5:00 PM">5:00 PM</option>
<option value="35" label="5:30 PM">5:30 PM</option>
<option value="36" label="6:00 PM">6:00 PM</option>
<option value="37" label="6:30 PM">6:30 PM</option>
<option value="38" label="7:00 PM">7:00 PM</option>
<option value="39" label="7:30 PM">7:30 PM</option>
<option value="40" label="8:00 PM">8:00 PM</option>
<option value="41" label="8:30 PM">8:30 PM</option>
<option value="42" label="9:00 PM">9:00 PM</option>
<option value="43" label="9:30 PM">9:30 PM</option>
<option value="44" label="10:00 PM">10:00 PM</option>
<option value="45" label="10:30 PM">10:30 PM</option>
<option value="46" label="11:00 PM">11:00 PM</option>
<option value="47" label="11:30 PM">11:30 PM</option>
</select>
</td>
<td>
<select ng-options="t.code as t.name for t in $parent.schedule.timeUntilValues|filter:schedule.timeGreater(schedule.scheduleFrom)" ng-model="schedule.until" class="form-control ng-pristine ng-valid">
<option value="" class="">Select</option>
<option value="0" label="12:30 AM">12:30 AM</option>
<option value="1" label="1:00 AM">1:00 AM</option>
<option value="2" label="1:30 AM">1:30 AM</option>
<option value="3" label="2:00 AM">2:00 AM</option>
<option value="4" label="2:30 AM">2:30 AM</option>
<option value="5" label="3:00 AM">3:00 AM</option>
<option value="6" label="3:30 AM">3:30 AM</option>
<option value="7" label="4:00 AM">4:00 AM</option>
<option value="8" label="4:30 AM">4:30 AM</option>
<option value="9" label="5:00 AM">5:00 AM</option>
<option value="10" label="5:30 AM">5:30 AM</option>
<option value="11" label="6:00 AM">6:00 AM</option>
<option value="12" label="6:30 AM">6:30 AM</option>
<option value="13" label="7:00 AM">7:00 AM</option>
<option value="14" label="7:30 AM">7:30 AM</option>
<option value="15" label="8:00 AM">8:00 AM</option>
<option value="16" label="8:30 AM">8:30 AM</option>
<option value="17" label="9:00 AM">9:00 AM</option>
<option value="18" label="9:30 AM">9:30 AM</option>
<option value="19" label="10:00 AM">10:00 AM</option>
<option value="20" label="10:30 AM">10:30 AM</option>
<option value="21" label="11:00 AM">11:00 AM</option>
<option value="22" label="11:30 AM">11:30 AM</option>
<option value="23" label="12:00 PM">12:00 PM</option>
<option value="24" label="12:30 PM">12:30 PM</option>
<option value="25" label="1:00 PM">1:00 PM</option>
<option value="26" label="1:30 PM">1:30 PM</option>
<option value="27" label="2:00 PM">2:00 PM</option>
<option value="28" label="2:30 PM">2:30 PM</option>
<option value="29" label="3:00 PM">3:00 PM</option>
<option value="30" label="3:30 PM">3:30 PM</option>
<option value="31" label="4:00 PM">4:00 PM</option>
<option value="32" label="4:30 PM">4:30 PM</option>
<option value="33" label="5:00 PM">5:00 PM</option>
<option value="34" label="5:30 PM">5:30 PM</option>
<option value="35" label="6:00 PM">6:00 PM</option>
<option value="36" label="6:30 PM">6:30 PM</option>
<option value="37" label="7:00 PM">7:00 PM</option>
<option value="38" label="7:30 PM">7:30 PM</option>
<option value="39" label="8:00 PM">8:00 PM</option>
<option value="40" label="8:30 PM">8:30 PM</option>
<option value="41" label="9:00 PM">9:00 PM</option>
<option value="42" label="9:30 PM">9:30 PM</option>
<option value="43" label="10:00 PM">10:00 PM</option>
<option value="44" label="10:30 PM">10:30 PM</option>
<option value="45" label="11:00 PM">11:00 PM</option>
<option value="46" label="11:30 PM">11:30 PM</option>
<option value="47" selected="selected" label="12:00 AM (next day)">12:00 AM (next day)</option>
</select>
</td>
<td>
<button ng-click="$parent.schedule.scheduleRemove($index)" class="form-control btn btn-primary">
<i class="fa fa-times">
</i>&nbsp;Remove</button>
</td>
</tr>
<!-- end ngRepeat: schedule in schedule.schedules -->
</tbody>
<tfoot>
<tr>
<td>
<button ng-click="schedule.scheduleAdd();" class="btn btn-primary form-control">
<i class="fa fa-plus">
</i>&nbsp;ADD</button>
</td>
<td colspan="3">
</td>
</tr>
</tfoot>
</table>
<!-- end any table -->                                
                </div>
            </div>
            <div ng-show="schedule.status == 1" class="text-center ng-hide">
                <button ng-click="schedule.cancel()" ng-disabled="schedule.spinner.count & gt; 0" class="btn btn-default">Cancel</button>&nbsp; <button ng-click="schedule.save()" ng-disabled="schedule.spinner.count & gt; 0" class="btn btn-primary">
                    <span translate="$loading" ng-show="$parent.schedule.spinner.count & gt; 0" class="ng-scope ng-hide">Loading...</span> <span translate="$continue" ng-hide="$parent.schedule.spinner.count & gt; 0" class="ng-scope">Continue</span>
                </button>
            </div>
        </div>
    </div>
</div>