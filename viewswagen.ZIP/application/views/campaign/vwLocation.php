<div class="panel panel-default ng-scope">
                <div class="panel-heading">
                    <button ng-click="location.edit()" ng-show="location.status == 2" class="pull-right btn btn-default ng-hide">Edit</button>
                    <h4 class="panel-title">
                    <i class="fa fa-location-arrow">
                    </i>&nbsp;Location</h4>
                    <div ng-show="location.status & gt; 0" class="small text-muted ng-hide">Please specify location where you would want to focus your campaign.<br>For multiple locations we advise you to have different campaigns.</div>
                </div>
                <div ng-show="location.status & gt; 0" class="slide-animation ng-hide">
                    <div ng-form="locationForm" class="panel-body ng-pristine ng-valid ng-valid-required">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <div>
                                        <div style="cursor:pointer" ng-click="location.modeSelect('radius')">
                                            <i ng-class="{'fa-check-square-o':location.mode == 'radius','fa-square-o':location.mode != 'radius'}" class="fa fa-square-o">
                                            </i>&nbsp;Advertisement specific for the address
                                        </div>
                                        <div ng-show="location.mode == 'radius'" style="padding-left:15px;padding-right:15px" class="ng-hide">
                                            <div class="panel panel-default">
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <div ng-show="location.geoSpinner.count & gt; 0" class="pull-right text-muted fade-animation ng-hide">
                                                            <i class="fa fa-refresh fa-spin">
                                                            </i>
                                                        </div>
                                                        Address
                                                        <div>
                                                            <div ng-show="location.status == 1" class="ng-hide">
                                                                <input type="text" ng-required="location.mode=='radius'" placeholder="Street address, City, Region, Country, ..." ng-model="location.address" class="form-control ng-pristine ng-valid ng-valid-required" name="address">
                                                            </div>
                                                            </div>
                                                            <div ng-show="location.lattitude" class="small ng-hide">
                                                                <div class="pull-right">
                                                                    <a ng-click="location.target()" style="cursor:pointer">
                                                                    <i class="fa fa-location-arrow">
                                                                    </i>&nbsp;Show</a>
                                                                </div>
                                                                <div class="text-muted ng-binding">0.000000&nbsp;0.000000</div>
</div>
<input type="hidden" ng-required="!!location.address&amp;&amp;location.geoSpinner.count==0&amp;&amp;location.mode=='radius'" ng-model="location.lattitude" name="location" class="ng-pristine ng-valid ng-valid-required">
</div>
</div>
                                                    <div ng-show="location.status == 1" class="ng-hide">
                                                        <div ng-show="!location.lattitude & amp; & amp; !!location.address & amp; & amp; location.geoSpinner.count == 0" class="small text-danger ng-hide">
<i class="fa fa-times">
</i>&nbsp;Unable to find location.</div>
                                                        <div ng-show="locationForm.address.$error.required & amp; & amp; !locationForm.address.$pristine" class="slide-animation text-danger ng-hide">
<i class="fa fa-warning">
</i>&nbsp;<span>Address is required</span>
</div>
                                                        <div ng-show="locationForm.location.$error.required" class="slide-animation text-danger ng-hide">
<i class="fa fa-warning">
</i>&nbsp;<span>Address should be valid</span>
</div>
</div>
                                                    <div class="form-group">
                                                        <div>Radius (in miles)</div>
                                                        <div ng-show="location.status == 1" class="ng-hide">
<select ng-required="location.mode=='radius'" ng-options="r.code as r.name for r in location.radiusValues" ng-model="location.radius" class="form-control ng-pristine ng-valid ng-valid-required" name="radius">
<option value="" class="">Select</option>
<option value="0" label="1">1</option>
<option value="1" label="3">3</option>
<option value="2" label="5">5</option>
<option value="3" label="7">7</option>
<option value="4" label="9">9</option>
<option value="5" label="11">11</option>
<option value="6" label="13">13</option>
<option value="7" label="15">15</option>
<option value="8" label="17">17</option>
<option value="9" label="19">19</option>
<option value="10" label="21">21</option>
<option value="11" label="23">23</option>
<option value="12" selected="selected" label="25">25</option>
<option value="13" label="27">27</option>
<option value="14" label="29">29</option>
<option value="15" label="30">30</option>
<option value="16" label="35">35</option>
<option value="17" label="40">40</option>
<option value="18" label="45">45</option>
<option value="19" label="50">50</option>
<option value="20" label="60">60</option>
<option value="21" label="70">70</option>
<option value="22" label="80">80</option>
<option value="23" label="90">90</option>
<option value="24" label="100">100</option>
<option value="25" label="200">200</option>
<option value="26" label="300">300</option>
<option value="27" label="400">400</option>
<option value="28" label="500">500</option>
<option value="29" label="500">500</option>
<option value="30" label="750">750</option>
<option value="31" label="1000">1000</option>
<option value="32" label="1250">1250</option>
<option value="33" label="1500">1500</option>
<option value="34" label="1750">1750</option>
<option value="35" label="2000">2000</option>
<option value="36" label="2250">2250</option>
<option value="37" label="2500">2500</option>
<option value="38" label="2750">2750</option>
<option value="39" label="3000">3000</option>
</select>
</div>
                                                        <div ng-show="location.status == 2" class="ng-binding ng-hide">25 mile(s)</div>
</div>
                                                    <div ng-show="location.status == 1" class="ng-hide">
                                                        <div ng-show="locationForm.radius.$error.required & amp; & amp; !locationForm.radius.$pristine" class="slide-animation text-danger ng-hide">
<i class="fa fa-warning">
</i>&nbsp;<span>Radius is required</span>
</div>
</div>
</div>
</div>
</div>
</div>
                                    <div>
                                        <div style="cursor:pointer" ng-click="location.modeSelect('region')">
<i ng-class="{'fa-check-square-o':location.mode == 'region','fa-square-o':location.mode != 'region'}" class="fa fa-square-o">
</i>&nbsp;Show within the state</div>
                                        <div ng-show="location.mode == 'region'" style="padding-left:15px;padding-right:15px" class="ng-hide">
                                            <div class="panel panel-default">
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <div ng-show="location.geoSpinner.count & gt; 0" class="pull-right text-muted fade-animation ng-hide">
<i class="fa fa-refresh fa-spin">
</i>
</div>State
                                                        <div>
                                                            <div ng-show="location.status == 1" class="ng-hide">
<select ng-required="location.mode=='region'" ng-model="location.state" class="form-control ng-pristine ng-valid ng-valid-required" name="state">
<option value="">Select</option>
<option value="Alabama">Alabama</option>
<option value="Alaska">Alaska</option>
<option value="Arizona">Arizona</option>
<option value="Arkansas">Arkansas</option>
<option value="California">California</option>
<option value="Colorado">Colorado</option>
<option value="Connecticut">Connecticut</option>
<option value="Delaware">Delaware</option>
<option value="Florida">Florida</option>
<option value="Georgia">Georgia</option>
<option value="Hawaii">Hawaii</option>
<option value="Idaho">Idaho</option>
<option value="Illinois">Illinois</option>
<option value="Indiana">Indiana</option>
<option value="Iowa">Iowa</option>
<option value="Kansas">Kansas</option>
<option value="Kentucky">Kentucky</option>
<option value="Louisiana">Louisiana</option>
<option value="Maine">Maine</option>
<option value="Maryland">Maryland</option>
<option value="Massachusetts">Massachusetts</option>
<option value="Michigan">Michigan</option>
<option value="Minnesota">Minnesota</option>
<option value="Mississippi">Mississippi</option>
<option value="Missouri">Missouri</option>
<option value="Montana">Montana</option>
<option value="Nebraska">Nebraska</option>
<option value="Nevada">Nevada</option>
<option value="New Hampshire">New Hampshire</option>
<option value="New Jersey">New Jersey</option>
<option value="New Mexico">New Mexico</option>
<option value="New York">New York</option>
<option value="North Carolina">North Carolina</option>
<option value="North Dakota">North Dakota</option>
<option value="Ohio">Ohio</option>
<option value="Oklahoma">Oklahoma</option>
<option value="Oregon">Oregon</option>
<option value="Pennsylvania">Pennsylvania</option>
<option value="Rhode Island">Rhode Island</option>
<option value="South Carolina">South Carolina</option>
<option value="South Dakota">South Dakota</option>
<option value="Tennessee">Tennessee</option>
<option value="Texas">Texas</option>
<option value="Utah">Utah</option>
<option value="Vermont">Vermont</option>
<option value="Virginia">Virginia</option>
<option value="Washington">Washington</option>
<option value="West Virginia">West Virginia</option>
<option value="Wisconsin">Wisconsin</option>
<option value="Wyoming">Wyoming</option>
</select>
</div>
                                                            <div ng-show="location.status == 2" class="ng-binding ng-hide">
</div>
</div>
</div>
                                                    <div ng-show="location.status == 1" class="ng-hide">
                                                        <div ng-show="locationForm.state.$error.required & amp; & amp; !locationForm.state.$pristine" class="slide-animation text-danger ng-hide">
<i class="fa fa-warning">
</i>&nbsp;<span>State is required</span>
</div>
</div>
</div>
</div>
</div>
</div>
                                    <div style="cursor:pointer" ng-click="location.modeSelect('country')">
<i ng-class="{'fa-check-square-o':location.mode == 'country','fa-square-o':location.mode != 'country'}" class="fa fa-square-o">
</i>&nbsp;Show within country</div>
</div>
</div>
                            <div class="col-sm-6">
                                <div data-label="campaign-location-map" style="height:300px;background-color:#ccc" class="form-group panel panel-default panel-content">
</div>
</div>
</div>
                        <div ng-show="location.status == 1" class="text-center ng-hide">
<button ng-click="location.cancel()" ng-disabled="location.spinner.count & gt; 0" class="btn btn-default">Cancel</button>&nbsp; <button ng-click="location.save()" ng-disabled="location.spinner.count & gt; 0" class="btn btn-primary">
<span translate="$loading" ng-show="$parent.location.spinner.count & gt; 0" class="ng-scope ng-hide">Loading...</span> <span translate="$continue" ng-hide="$parent.location.spinner.count & gt; 0" class="ng-scope">Continue</span>
</button>
</div>
</div>
</div>