<div class="panel panel-default ng-scope">
                <div class="panel-heading">
<button ng-click="targetAudience.edit()" ng-show="targetAudience.status == 2" class="pull-right btn btn-default ng-hide">Edit</button>
<h4 class="panel-title">
<i class="fa fa-dot-circle-o">
</i>&nbsp;Target Audience</h4>
                    <div ng-show="targetAudience.status & gt; 0" class="small text-muted ng-hide">Please specify target categories for your advertisement</div>
</div>
                <div ng-show="targetAudience.status & gt; 0" class="slide-animation ng-hide">
                    <div ng-form="targetAudienceForm" class="panel-body ng-pristine ng-invalid ng-invalid-required">
                        <div>
<b class="form-group">Key Words</b>
<p ng-show="targetAudience.status == 1" class="small text-muted ng-hide">You could target your audience by any key word in the business name of destination address.<br>e.g. you could use 'Home Depot' or 'Menards', in order to target audience who're on their way to these stores.</p>
                            <div ng-show="targetAudience.status == 1" ng-form="targetAudienceTagForm" class="row ng-pristine ng-invalid ng-invalid-required ng-hide">
                                <div class="col-sm-10 form-group">
<input type="text" style="text-transform:lowercase" required="" class="form-control ng-pristine ng-invalid ng-invalid-required" ng-model="targetAudience.tag" name="tag">
                                    <div ng-show="targetAudienceTagForm.tag.$error.required & amp; & amp; !targetAudienceTagForm.tag.$pristine" class="slide-animation text-danger ng-hide">
<i class="fa fa-warning">
</i>&nbsp;<span>Tag is required</span>
</div>
</div>
                                <div class="col-sm-2 form-group">
<button ng-click="targetAudience.tagAdd()" class="btn btn-default form-control">Add</button>
</div>
</div>
                            <div class="well">
                                <div ng-show="targetAudience.tags.length == 0" class="">You didn't specify any tag yet.</div>
                                <div>
<!-- ngRepeat: (index,tag) in targetAudience.tags track by index -->
</div>
</div>
<b class="form-group">Campaign Categories <span class="ng-binding">(0 selected)</span>
</b>
<p ng-show="targetAudience.status == 1" class="small text-muted ng-hide">We will use destination address in order to determine which advertisement would be more interesting for the viewer.<br>Please choose for which categories your advertisement would be more interesting - you can always choose all options, but then you possibly will not be able to focus your advertisement on desired audience.<br>It doesn't neccessary mean that your advertisement won't show up for unchecked categories - in some cases we will use different ways to determine if advertisement might be interesting (e.g. address near destination)</p>
                            <div ng-show="targetAudience.status == 1" class="form-group ng-hide">
                                <div ng-click="targetAudience.selectAll()" class="btn btn-sm btn-warning">
<i class="fa fa-check-square-o">
</i>&nbsp;Select All</div>&nbsp;
                                <div ng-click="targetAudience.removeSelection()" class="btn btn-sm btn-warning">
<i class="fa fa-square-o">
</i>&nbsp;Clear Selection</div>
</div>
<!-- ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Automotive" class="ng-scope">Automotive</span>&nbsp;<span class="ng-binding">(0/4)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Car Dealerships" class="ng-scope">Car Dealerships</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Car Rental Companies" class="ng-scope">Car Rental Companies</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Auto Repair Shops" class="ng-scope">Auto Repair Shops</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Car Washes" class="ng-scope">Car Washes</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Beauty" class="ng-scope">Beauty</span>&nbsp;<span class="ng-binding">(0/3)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Beauty Salons" class="ng-scope">Beauty Salons</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Hair Salons" class="ng-scope">Hair Salons</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Spas" class="ng-scope">Spas</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Education" class="ng-scope">Education</span>&nbsp;<span class="ng-binding">(0/2)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Schools" class="ng-scope">Schools</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Colleges" class="ng-scope">Colleges</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Entertainment" class="ng-scope">Entertainment</span>&nbsp;<span class="ng-binding">(0/9)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Amusement Parks" class="ng-scope">Amusement Parks</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Aquariums &amp; related" class="ng-scope">Aquariums &amp; related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Art Galleries" class="ng-scope">Art Galleries</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Bowling Establishments" class="ng-scope">Bowling Establishments</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Casinos" class="ng-scope">Casinos</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Film Theatres" class="ng-scope">Film Theatres</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Museums" class="ng-scope">Museums</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Stadiums" class="ng-scope">Stadiums</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Zoo" class="ng-scope">Zoo</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Finance" class="ng-scope">Finance</span>&nbsp;<span class="ng-binding">(0/4)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="ATMs" class="ng-scope">ATMs</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Banks" class="ng-scope">Banks</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Finance &amp; related" class="ng-scope">Finance &amp; related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Insurance Agencies" class="ng-scope">Insurance Agencies</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Food" class="ng-scope">Food</span>&nbsp;<span class="ng-binding">(0/7)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Bakeries" class="ng-scope">Bakeries</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Cafes" class="ng-scope">Cafes</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Food" class="ng-scope">Food</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Super Markets &amp; Grocery Stores" class="ng-scope">Super Markets &amp; Grocery Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Meal Delivery Businesses" class="ng-scope">Meal Delivery Businesses</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Take Out Restaurants" class="ng-scope">Take Out Restaurants</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Restaurants" class="ng-scope">Restaurants</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Funerals &amp; Cemetaries" class="ng-scope">Funerals &amp; Cemetaries</span>&nbsp;<span class="ng-binding">(0/2)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Cemeteries" class="ng-scope">Cemeteries</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Funeral Home" class="ng-scope">Funeral Home</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="General Business" class="ng-scope">General Business</span>&nbsp;<span class="ng-binding">(0/1)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Business General" class="ng-scope">Business General</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Government" class="ng-scope">Government</span>&nbsp;<span class="ng-binding">(0/8)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="City Hall &amp; related" class="ng-scope">City Hall &amp; related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Court House" class="ng-scope">Court House</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Embassy" class="ng-scope">Embassy</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Fire House" class="ng-scope">Fire House</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Libraries" class="ng-scope">Libraries</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Local Government Buildings" class="ng-scope">Local Government Buildings</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Law Enforcement" class="ng-scope">Law Enforcement</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Post Office" class="ng-scope">Post Office</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Health" class="ng-scope">Health</span>&nbsp;<span class="ng-binding">(0/2)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Fitness Clubs" class="ng-scope">Fitness Clubs</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Health Stores" class="ng-scope">Health Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Home Goods" class="ng-scope">Home Goods</span>&nbsp;<span class="ng-binding">(0/2)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Hardware Stores" class="ng-scope">Hardware Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Home Goods Stores" class="ng-scope">Home Goods Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Home Services" class="ng-scope">Home Services</span>&nbsp;<span class="ng-binding">(0/4)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Electrician" class="ng-scope">Electrician</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Construction Companies" class="ng-scope">Construction Companies</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Painting Contractor" class="ng-scope">Painting Contractor</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Roofers" class="ng-scope">Roofers</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Medical" class="ng-scope">Medical</span>&nbsp;<span class="ng-binding">(0/4)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Dentists &amp; related" class="ng-scope">Dentists &amp; related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Doctors Office &amp; Related" class="ng-scope">Doctors Office &amp; Related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Hospitals" class="ng-scope">Hospitals</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Physical Therapists" class="ng-scope">Physical Therapists</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Nightlife" class="ng-scope">Nightlife</span>&nbsp;<span class="ng-binding">(0/2)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Bars" class="ng-scope">Bars</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Night Clubs" class="ng-scope">Night Clubs</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Pets" class="ng-scope">Pets</span>&nbsp;<span class="ng-binding">(0/2)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Pet Supply Store &amp; Related" class="ng-scope">Pet Supply Store &amp; Related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Animal Hospitals &amp; Veterinarians" class="ng-scope">Animal Hospitals &amp; Veterinarians</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Professional Services" class="ng-scope">Professional Services</span>&nbsp;<span class="ng-binding">(0/2)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Accounting Offices &amp; related" class="ng-scope">Accounting Offices &amp; related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Attorneys" class="ng-scope">Attorneys</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Real Estate" class="ng-scope">Real Estate</span>&nbsp;<span class="ng-binding">(0/1)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Real Estate Agents" class="ng-scope">Real Estate Agents</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Relgious" class="ng-scope">Relgious</span>&nbsp;<span class="ng-binding">(0/1)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Churches &amp; related" class="ng-scope">Churches &amp; related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Religious" class="ng-scope">Religious</span>&nbsp;<span class="ng-binding">(0/4)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Hindu Temples" class="ng-scope">Hindu Temples</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Mosque" class="ng-scope">Mosque</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Religious Places" class="ng-scope">Religious Places</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Synagogue" class="ng-scope">Synagogue</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Retail" class="ng-scope">Retail</span>&nbsp;<span class="ng-binding">(0/21)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Book Stores" class="ng-scope">Book Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Apparel Retail" class="ng-scope">Apparel Retail</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Convenience Stores &amp; Gas Stations" class="ng-scope">Convenience Stores &amp; Gas Stations</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Department Stores" class="ng-scope">Department Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Electronics Retailer" class="ng-scope">Electronics Retailer</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Florists" class="ng-scope">Florists</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Shopping Center" class="ng-scope">Shopping Center</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Storage" class="ng-scope">Storage</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Store" class="ng-scope">Store</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="DVD Rental Stores" class="ng-scope">DVD Rental Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Movers" class="ng-scope">Movers</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Parking Lot" class="ng-scope">Parking Lot</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Pharmacies" class="ng-scope">Pharmacies</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Plumbers" class="ng-scope">Plumbers</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Shoe Stores" class="ng-scope">Shoe Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Furniture Retailer" class="ng-scope">Furniture Retailer</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Gas Station &amp; Convenience Stores" class="ng-scope">Gas Station &amp; Convenience Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Jewelry Stores" class="ng-scope">Jewelry Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Laundry Mats" class="ng-scope">Laundry Mats</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Liqour Stores" class="ng-scope">Liqour Stores</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Locksmiths" class="ng-scope">Locksmiths</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Sports &amp; Recreation" class="ng-scope">Sports &amp; Recreation</span>&nbsp;<span class="ng-binding">(0/4)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Bicycle Shops" class="ng-scope">Bicycle Shops</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Camping Grounds &amp; related" class="ng-scope">Camping Grounds &amp; related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Park" class="ng-scope">Park</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="RV Parks" class="ng-scope">RV Parks</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Transportation" class="ng-scope">Transportation</span>&nbsp;<span class="ng-binding">(0/4)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Bus Stops, Stations &amp; Related" class="ng-scope">Bus Stops, Stations &amp; Related</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Subway" class="ng-scope">Subway</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Taxi Stand" class="ng-scope">Taxi Stand</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Train Stations" class="ng-scope">Train Stations</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
                            <div ng-repeat="group in targetAudience.groups" class="form-group ng-scope">
                                <div ng-click="$parent.targetAudience.groupToggle($index)" style="cursor:pointer">
<i ng-class="{'fa-square-o':!$parent.targetAudience.groupSelect[$index],'fa-check-square-o':$parent.targetAudience.groupSelect[$index] == group.categories.length,'fa-check-square':$parent.targetAudience.groupSelect[$index] & amp; & amp; $parent.targetAudience.groupSelect[$index] != group.categories.length}" class="fa fa-square-o">
</i>&nbsp; <span translate="Travel" class="ng-scope">Travel</span>&nbsp;<span class="ng-binding">(0/3)</span>
</div>
                                <div style="padding-left:20px" class="row small">
<!-- ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Airports" class="ng-scope">Airports</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Lodges" class="ng-scope">Lodges</span>
</div>
<!-- end ngRepeat: category in group.categories -->
                                    <div style="cursor:pointer" class="col-sm-3 ng-scope">
<i  class="fa fa-square-o">
</i>&nbsp;<span translate="Travel Agencies" class="ng-scope">Travel Agencies</span>
</div>
<!-- end ngRepeat: category in group.categories -->
</div>
</div>
<!-- end ngRepeat: group in targetAudience.groups -->
</div>
                        <div ng-show="targetAudience.status == 1" class="text-center ng-hide">
<button ng-click="targetAudience.cancel()" ng-disabled="targetAudience.spinner.count & gt; 0" class="btn btn-default">Cancel</button>&nbsp; <button ng-click="targetAudience.save()" ng-disabled="targetAudience.spinner.count & gt; 0" class="btn btn-primary">
<span translate="$loading" ng-show="$parent.targetAudience.spinner.count & gt; 0" class="ng-scope ng-hide">Loading...</span> <span translate="$continue" ng-hide="$parent.targetAudience.spinner.count & gt; 0" class="ng-scope">Continue</span>
</button>
</div>
</div>
</div>
</div>