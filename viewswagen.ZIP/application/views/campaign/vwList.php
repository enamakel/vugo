<div class="slide-animation vw-scope" style="">
    <?php if(!isset($campaignList) || count($campaignList)<1): ?>
       <div class="form-group">You don't have any campaigns yet..</div>
    <?php else:?>
        <div class="panel-content panel panel-default vw-hide">
            <table class="table table-stripped">
                <thead>
                    <tr>
                        <th class="col-sm-6">Name</th>
                        <th class="col-sm-2">Approval</th>
                        <th class="col-sm-2">Setup</th>
                        <th class="col-sm-2">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    <?php endif;?>
</div>