<ol class="breadcrumb ng-scope">
    <li>
        <a href="#/">Campaigns</a>
    </li>
    <li class="active">
        Campaign Details
    </li>
</ol>