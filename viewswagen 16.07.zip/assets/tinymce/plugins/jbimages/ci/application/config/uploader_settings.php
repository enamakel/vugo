<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* This config is a wrapper for the file below: */

require('../config.php');



/* End of file uploader_settings.php */
/* Location: ./system/application/config/uploader_settings.php */
