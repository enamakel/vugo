     <footer>
     <p>&copy; Company <?php echo date('Y') ?>. ark Admin Panel for Codeigniter. Downloaded from <a href='http://devzone.co.in' target='_blank'>http://devzone.co.in</a></p>
      </footer>
    </div> <!-- /container -->
  
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo HTTP_JS_PATH; ?>jquery.js"></script>
    <script src="<?php echo HTTP_JS_PATH; ?>bootstrap.min.js"></script>
  </body>
</html>
