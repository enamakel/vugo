<?php
$this->load->view('vwHeaderOld');
?>
<!--  
Load Page Specific CSS and JS here
Author : Abhishek R. Kaushik 
Downloaded from http://devzone.co.in
-->
<link href="<?php echo HTTP_CSS_PATH; ?>starter-template.css" rel="stylesheet">
 
<div class="page-header container">
  <h1><small>SignUp</small></h1>
</div>


<div class="container">
    <div class="panel panel-default">
  <div class="panel-body">
    Company Name,
    123, Street,
    City, 4101254
    Country
  </div>
</div>


</div>

  
     <hr>
<?php
$this->load->view('vwFooterOld');
?>